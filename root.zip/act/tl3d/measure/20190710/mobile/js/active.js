
var actConfig;
var actInfo;

var actLoginInit = function(data){
    actConfigFun();
    actInfoFun();
};
var actUnLoginInit = function(data){
    actConfigFun();
};

//获取活动配置信息
var actConfigFun = function(){
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/active/config";
	var data = {};
	cyja.client.ajax('get', url, data, function(res){
		//res
		if(res.code === 10000) {
			actConfig = res.data;
		}
	});
};

//获取查询参与信息
var actInfoFun = function(){
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/active/info";
	var data = {};
	cyja.client.ajax('post', url, data, function(res){
		//res
		if(res.code === 10000) {
            actInfo = res.data;
            $('#pop2 .t2').html(actInfo.giftCode);
		}
	});
};

//获取痴情人
var actResultFun = function(){
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/result";
	var data = {
    	birthday: tl.month+"."+tl.date,
    	sex: tl.sex
    };
	cyja.client.ajax('post', url, data, function(res){
		//res
		if(res.code === 10000) {
            var name = res.data.name;
            var code = res.data.code;
            var src = "";
            for (let i = 0; i < roleArray.length; i++) {
                const e = roleArray[i];
                if(e.code == code){
                    src = e.src;
                    break;
                }
            }
            $('#renwu').attr('src', src);
		}else{
            alert(res.message);
        }
	});
};

//获取查询参与信息
var actSaveFun = function(){
    if(actInfo){
        popup($("#pop2"));
        return;
    }
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/active/save";
	var data = {
        content: JSON.stringify(tl),
    	birthday: tl.month+"."+tl.date,
    	sex: tl.sex
    };
	cyja.client.ajax('post', url, data, function(res){
		//res
		if(res.code === 10000) {
			$('#pop2 .t2').html(res.data);
            popup($("#pop2"));
		}else{
            alert(res.message);
        }
	});
};

var roleArray = [
    {name: '阿紫', code: '1', src: '/act/tl3d/measure/20190710/mobile/img/renwu2.png'},
    {name: '游坦之', code: '2', src: '/act/tl3d/measure/20190710/mobile/img/renwu7.png'},
    {name: '天山童姥', code: '3', src: '/act/tl3d/measure/20190710/mobile/img/renwu6.png'},
    {name: '虚竹', code: '4', src: '/act/tl3d/measure/20190710/mobile/img/renwu8.png'},
    {name: '王语嫣', code: '5', src: '/act/tl3d/measure/20190710/mobile/img/renwu1.png'},
    {name: '李秋水', code: '6', src: '/act/tl3d/measure/20190710/mobile/img/renwu9.png'},
    {name: '乔峰', code: '7', src: '/act/tl3d/measure/20190710/mobile/img/renwu3.png'},
    {name: '段正淳', code: '8', src: '/act/tl3d/measure/20190710/mobile/img/renwu10.png'},
    {name: '段誉', code: '9', src: '/act/tl3d/measure/20190710/mobile/img/renwu5.png'},
    {name: '阿朱', code: '10', src: '/act/tl3d/measure/20190710/mobile/img/renwu4.png'},
    {name: '慕容复', code: '11', src: '/act/tl3d/measure/20190710/mobile/img/renwu11.png'},
    {name: '钟灵', code: '12', src: '/act/tl3d/measure/20190710/mobile/img/renwu12.png'},
    {name: '无崖子', code: '13', src: '/act/tl3d/measure/20190710/mobile/img/renwu13.png'},
];