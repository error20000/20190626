package com.changyou.activity.util;

import java.text.SimpleDateFormat;

public class DateUtil {
    public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
}
