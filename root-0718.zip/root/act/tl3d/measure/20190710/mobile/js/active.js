
var actConfig;
var actInfo;

var actLoginInit = function(data){
    actConfigFun();
    actInfoFun();
    setWeiXin();
};
var actUnLoginInit = function(data){
    actConfigFun();
    actInfoFun();
    setWeiXin();
};

var setWeiXin = function(){
    //var src = "http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJGrDY3cRGPxLdiaOljLZH9YCMXl5R17LpVONiboviaeut1emFestyJyMdylqhCaiaLbljGl3EBkd0vDA/132";
    $('.bg8 .touxiang div').css('background-image', 'url('+cyja.glob.userInfo.headimgurl+')');
    $('.bg8 .name').html(cyja.glob.userInfo.nickname);
};

//获取活动配置信息
var actConfigFun = function(){
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/active/config";
	var data = {};
	cyja.client.ajax('get', url, data, function(res){
		//res
		if(res.code === 10000) {
			actConfig = res.data;
		}
	});
};

//获取查询参与信息
var actInfoFun = function(){
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/active/info";
	var data = {};
	cyja.client.ajax('post', url, data, function(res){
		//res
		if(res.code === 10000) {
            actInfo = res.data;
            $('#pop2 .t1').html("恭喜你获得"+res.data.giftName);
            $('#pop2 .t2').html(res.data.giftCode);
		}
	});
};

//获取痴情人
var actResultFun = function(){
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/result";
	var data = {
    	birthday: tl.month+"."+tl.date,
    	sex: tl.sex
    };
	cyja.client.ajax('post', url, data, function(res){
		//res
		if(res.code === 10000) {
            var name = res.data.name;
            var code = res.data.code;
            var src = "";
            for (let i = 0; i < roleArray.length; i++) {
                const e = roleArray[i];
                if(e.code == code){
                    src = e.src;
                    break;
                }
            }
            $('#renwu').attr('src', src);
		}else{
            alert(res.message);
        }
	});
};

//获取查询参与信息
var actSaveFun = function(){
    if(actInfo){
        popup($("#pop2"));
        return;
    }
	var url = cyja.options.host + "/wb/" + cyja.options.server + "/active/save";
	var data = {
        content: JSON.stringify(tl),
    	birthday: tl.month+"."+tl.date,
    	sex: tl.sex
    };
	cyja.client.ajax('post', url, data, function(res){
		//res
		if(res.code === 10000) {
            $('#pop2 .t1').html("恭喜你获得"+res.data.giftName);
			$('#pop2 .t2').html(res.data.giftCode);
            popup($("#pop2"));
		}else if(res.code === 20011){ //已参与
            $('#pop2 .t1').html("恭喜你获得"+res.data.giftName);
			$('#pop2 .t2').html(res.data.giftCode);
            popup($("#pop2"));
        }else if(res.code === 20012){
            alert("礼包码已经抢光了，保存测试结果并分享，截图上传到微信公众号后台也能领取1000绑元礼包奖励！");
        }else{
            alert(res.message);
        }
	});
};

var roleArray = [
    {name: '阿紫', code: '1', src: '/act/tl3d/measure/20190710/mobile/img/renwu2.png'},
    {name: '游坦之', code: '2', src: '/act/tl3d/measure/20190710/mobile/img/renwu7.png'},
    {name: '天山童姥', code: '3', src: '/act/tl3d/measure/20190710/mobile/img/renwu6.png'},
    {name: '虚竹', code: '4', src: '/act/tl3d/measure/20190710/mobile/img/renwu8.png'},
    {name: '王语嫣', code: '5', src: '/act/tl3d/measure/20190710/mobile/img/renwu1.png'},
    {name: '李秋水', code: '6', src: '/act/tl3d/measure/20190710/mobile/img/renwu9.png'},
    {name: '乔峰', code: '7', src: '/act/tl3d/measure/20190710/mobile/img/renwu3.png'},
    {name: '段正淳', code: '8', src: '/act/tl3d/measure/20190710/mobile/img/renwu10.png'},
    {name: '段誉', code: '9', src: '/act/tl3d/measure/20190710/mobile/img/renwu5.png'},
    {name: '阿朱', code: '10', src: '/act/tl3d/measure/20190710/mobile/img/renwu4.png'},
    {name: '慕容复', code: '11', src: '/act/tl3d/measure/20190710/mobile/img/renwu11.png'},
    {name: '钟灵', code: '12', src: '/act/tl3d/measure/20190710/mobile/img/renwu12.png'},
    {name: '无崖子', code: '13', src: '/act/tl3d/measure/20190710/mobile/img/renwu13.png'},
];