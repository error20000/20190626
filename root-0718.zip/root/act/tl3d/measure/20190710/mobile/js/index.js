if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
	new WOW().init();
};


//横竖屏
function hengshuping(){
if(window.orientation==180||window.orientation==0){
  setTimeout(function(){$(".horizontal").hide()},200)
}
if(window.orientation==90||window.orientation==-90){
  $(".horizontal").show();
}
}
window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", hengshuping, false);

var tl = {
	"id": "",
	"month" : "",
	"date" : "",
	"sex" : "",
	"three" : "",
	"four" : "",
	"five" : "",
	"six" : "",
	"seven" : "",
	"star": ""
}



$(function(){
	function jieping(){
		html2canvas($("#capture"), {  
            //height: $("#contbox").outerHeight() + 20,  
               // width: $("#contbox").outerWidth() + 20  ,
                onrendered: function(canvas) {
                //将canvas画布放大若干倍，然后盛放在较小的容器内，就显得不模糊了
                var timestamp = Date.parse(new Date());
                //把截取到的图片替换到a标签的路径下载  
                //$("#down1").attr('href',canvas.toDataURL());  
				$('#saveImg').attr('src',canvas.toDataURL());
				//console.log(canvas.toDataURL());
                //下载下来的图片名字  
                //$("#down1").attr('download',timestamp + '.png') ;   
                //document.body.appendChild(canvas);  
			},
			useCORS: true
            //可以带上宽高截取你所需要的部分内容 
        });
	}
	
	$('.bg').css('height',$('.wrapper').height()+'px');
	var heig = $('.bg').height() * $('.bg').length + 'px';
	$('.wraps').css('height',heig);
	
	//$('.wraps').css({'top': '-10672px'});
	
	// 根据生日的月份和日期，计算星座。
	function getAstro(m,d){
	  return "魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯".substr(m*2-(d<"102223444433".charAt(m-1)- -19)*2,2);
	}
	//alert(getAstro(6,29));

	var move;
	function next(){
		clearTimeout(move);
		move = setTimeout(function(){
			mySwiper.unlockSwipeToNext();
			mySwiper.slideNext();
			mySwiper.lockSwipeToPrev();
			mySwiper.lockSwipeToNext();
		},300);
	}
	var move;
	function moveL(n){
		clearTimeout(move);
		move = setTimeout(function(){
			var moveT = $('.wraps').position().top;
			var moveS = - $('.wrapper').height();
			$('.wraps').css({'top': moveT}).animate({'top':moveS*n},300,function(){
				if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
					new WOW().init();
				};
				if(n==8 && $('#renwu').attr('src').indexOf('renwu') && $('#ren').attr('src')!=''){
					jieping();
				}
			});	
		},200);
	}
	/*function moveL(n){
		var moveT = $('.wraps').position().top;
		var moveS = - $('.wrapper').height();
		$('.wraps').css({'top': moveT}).animate({'top':moveS*n},300,function(){
			if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
				new WOW().init();
			};
		});	
		//console.log(moveT);
		//console.log(moveS);
	}*/
	
	$('.djcs').click(function(){
		if(!actConfig){
			alert("活动未开始！");
			return;
		}
		var startDate = new Date(actConfig.startDate);
		var endDate = new Date(actConfig.endDate);
		var curDate = new Date();
		if(curDate.getTime() < startDate.getTime()){
			alert("活动未开始");
			return;
		}
		if(curDate.getTime() > endDate.getTime()){
			alert("活动已结束");
			return;
		}
		moveL(1);
	});
	
	
	var yuehtml = '';
	for(var i=1;i<=12;i++){
		yuehtml += '<option value="'+i+'">'+i+'月</option>';
	}
	$('#month').append(yuehtml);
	function getMonthDay(year, month) {
	  var days = new Date(year, month , 0).getDate()
	  return days
	}
	
	$('#month').change(function(){
		var datehtml = '';
		for(var i=1;i<=getMonthDay(2019,$('#month').val());i++){
			datehtml += '<option value="'+i+'">'+i+'</option>';
		}
		$('#date').append(datehtml);
	});
	
	
	$('#date').change(function(){
		if($('#date').val()!='' && $('#month').val()!=''){
			tl.month = $('#month').val();
			tl.date = $('#date').val();
			tl.star = getAstro(tl.month,tl.date)
			moveL(2);
		}
	});
	

	
	//第二题
	$('input:radio[name="sex"]').click(function(){
		var val=$('input:radio[name="sex"]:checked').val();
		if(val==null){
			return false;
		}else{
			tl.sex = val;
			//console.log('性别 1表示男 0表示女：'+val);  //性别 1表示男 0表示女
			moveL(3);
		}
	});
	
	//第3题
	$('.three').find('li').each(function(i){
		$(this).bind('click',function(){
			tl.three = $(this).html();
			$(this).addClass('active').siblings().removeClass('active');
			moveL(4);
		});
	});	
	
	//第4题
	$('.four').find('li').each(function(i){
		$(this).bind('click',function(){
			tl.four = $(this).html();
			$(this).addClass('active').siblings().removeClass('active');
			moveL(5);
		});
	});	
	
	//第5题
	$('.five').find('li').each(function(i){
		$(this).bind('click',function(){
			tl.five = $(this).html();
			$(this).addClass('active').siblings().removeClass('active');
			moveL(6);
		});
	});	
	
	//第6题
	$('.six').find('li').each(function(i){
		$(this).bind('click',function(){
			tl.six = $(this).html();
			$(this).addClass('active').siblings().removeClass('active');
			moveL(7);
		});
	});	
	
	//第7题
	var pos = 'img/';
	var src1;
	function renwu(){
		actResultFun();
		moveL(8);
		/*if(tl.star=='巨蟹'){
			src1 = pos+'renwu1.png';
		}else if(tl.star=='天蟹' || tl.star == '魔羯'){
			if(tl.sex == 0){
				src1 = pos+'renwu2.png';
			}else{
				src1 = pos+'renwu7.png';
			}
		}else if(tl.star=='狮子'){
			if(tl.sex == 0){
				src1 = pos+'renwu9.png';
			}else{
				src1 = pos+'renwu3.png';
			}
		}else if(tl.star=='白羊'){
			src1 = pos+'renwu4.png';
		}else if(tl.star=='双鱼'){
			src1 = pos+'renwu5.png';
		}else if(tl.star=='处女' || tl.star == '金牛'){
			if(tl.sex == 0){
				src1 = pos+'renwu6.png';
			}else{
				src1 = pos+'renwu8.png';
			}
		}else if(tl.star=='天秤'){
			src1 = pos+'renwu10.png';
		}else if(tl.star=='水瓶'){
			src1 = pos+'renwu11.png';
		}else if(tl.star=='射手'){		//钟灵
			src1 = pos+'renwu12.png';
		}else if(tl.star=='双子'){
			src1 = pos+'renwu13.png';
		}
		console.log(src1);
		$('#renwu').attr('src',src1);*/
	}
	$('.seven').find('li').each(function(i){
		$(this).bind('click',function(){
			tl.seven = $(this).html();
			console.log(tl);
			$(this).addClass('active').siblings().removeClass('active');
			renwu();
			/*var mySwiper = new Swiper('.swiper-container', {
			  direction: 'vertical',
			  loop : true,
			});
			mySwiper.slideTo(9);
			mySwiper.lockSwipeToPrev();
			mySwiper.lockSwipeToNext();*/
		});
	});	
	
	//魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯
	
	
	
	
	//领绑元礼包
	$('.but1').click(function(){
		//popup($("#pop2"));
		actSaveFun();
		//alert("分享好友 即可100%领绑元礼包");
	});
	
	//分享
	//popup($("#pop1"));
	
	$('#pop1').click(function(){
		$(this).hide();
		if(isExist($('#Overlay'))) $('#Overlay').remove();
		if(isExist($('#Overlay1'))) $('#Overlay1').remove();
	});
	
	 //再测一次
	 $('.but2').click(function(){
		/*mySwiper.unlockSwipeToNext();
		mySwiper.unlockSwipeToPrev();
		mySwiper.lockSwipeToPrev();
		mySwiper.lockSwipeToNext();
		mySwiper.destroy();
		mySwiper = new Swiper('.swiper-container', {
		  direction: 'vertical',
		  loop : true,
		});*/
		//alert(123);
		//window.location.reload();
		window.location.href = window.location.href.split("?")[0] +"?"+new Date().getTime();
	 });

	//微信分享
	var shareToWeiXin = new ShareToWx({
		shareUrl : "",
		shareImg : "http://i0.cy.com/tl3d/pic/2019/07/10/share.png",
		shareTitle : "星宿上线 你是天龙3D的哪个痴情人",
		shareDesc : "测天龙痴情人 100%领300礼包",
		microPubNo : "tl3dr",
		callback:function(){
		}
	});
    
});

