//插入样式
var style =
    "<style type='text/css'>\
    #cy_top{ background: url(http://i1.cy.com/xtsdg_m/main/20140313/m_cy_bd.jpg) center bottom no-repeat; padding: 1em 0.5em 1.2em; overflow: hidden; }\
    #cy_top span{ float: right; font-size: 1em; color: #c31e61; font-weight: bold; line-height:1.5em;}\
    .cyLogo{ display: block; float: left;width: 24.37%;height: 100%}\
    #cy_bot{ background: url(http://i1.cy.com/xtsdg_m/main/20140313/m_cy_bd.jpg) center top no-repeat #f0f0f0; padding: 1em 0.5em ; overflow: hidden;}\
    #cy_bot span{float: right; padding-right: 0;width: 8.46%;}\
    @media screen and (min-width:540px)and (orientation:landscape)\
    {\
        #cy_top span,#cy_bot span{ font-size: 1.5em; line-height: 2em;}\
        .cyLogo{ width: 117px; height: 48px;}\
    }</style>";
$(style).appendTo('head');
//插入头部和底部
//$('<div id="cy_top"><a class="cyLogo">搜狐畅游</a></div>').prependTo('body');<span class="bkTop"><i class="iconfont">&#xf0010;</i></span>
$('<div id="cy_bot"><a class="cyLogo"><img src="http://i1.cy.com/cy/public/20150519/cy_logo_dark.png"></a><span class="bkTop"><img src="http://i0.cy.com/www/public/nav/scroll_top.png" alt=""></span></div>').appendTo('body');
//返回顶部
$('.bkTop').click(function(){
    window.scrollTo(0, 1);
});